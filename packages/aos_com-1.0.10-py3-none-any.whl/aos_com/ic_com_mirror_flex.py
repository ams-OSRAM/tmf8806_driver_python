# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This is test class for communication with ICs. 
This is a more advanced version of the IcComMirror. 
It can do wider addresses for larger address ranges (e.g. 16-bit addressing)
and it can be configured for big or little endian addressing. 
Data is always organised as bytes so it will be written as you transmit it on
I2C/SPI. I.e. first byte goes to the address that was specified, next goes
to address+1, etc.
"""

from aos_com.ic_com import IcCom

class IcComMirrorFlex(IcCom):

    # Version log 
    # 1.0 first working version
    VERSION = 1.0

    def __init__(self, log=False, exception_on_error=True, pattern_start:int=17, pattern_step:int=3, memory_size:int=256, addr_width:int=1, addr_endian='little' ):
        """
        Constructor, default is to not produce exceptions, just log the errors
        Args:
            log (TYPE, optional): Print messages. Defaults to False.
            exception_on_error (TYPE, optional): Raise an exception in error case, if false only log error. Defaults to False.
            pattern_start (int, optional): Start byte to fill the memory that is used as mirror. Defaults to 17.
            pattern_step (int, optional): Value that is added for filling the memory for each byte. Defaults to 0x03.
            memory_size (int, optional): How big the mirror shall be. Defaults to 256. For 16-bit addressing use e.g. 4096.
            addr_width_in_bytes (int, optional): How many bytes to use for addressing. Defaults to 1. With 1 you can address
            up to 256 bytes of memory. If you want to emulate 16-bit addressing use e.g. 4096 for memory size and set this to 2. 
            addr_endian (str, optional): either big or little for address endianess. Defaults to little.
        """
        super().__init__(log,exception_on_error)
        self._reg_addr = 0
        self.gpio_value = 0                 # default all 0
        self.memory_size = memory_size
        self.addr_width = addr_width
        self.addr_endian = addr_endian
        self._buffer = [0xFF & (pattern_start + pattern_step*x) for x in range(self.memory_size)]     # write some pattern to not just have uninit or all 0s

    def __del__(self):
        """Cleanup."""
        super().__del__()

    # -----------------------------------------------------------------------------------        
    # I2C functions ---------------------------------------------------------------------
    # -----------------------------------------------------------------------------------

    def i2cOpen(self, i2c_speed:int=1000000) -> int:
        """Open an I2C interface.        """
        fn_name = "i2cOpen"
        status = self._OK
        self._log(fn_name)
        return status 

    def i2cClose(self) -> int:
        """ Function to close a I2C interface. """
        fn_name = "i2cClose"
        status = self._OK
        self._log(fn_name)
        return status 
            
    def i2cTx(self,devaddr:int,tx:list) -> int:
        """Function to transmit given bytes on I2C """
        fn_name = "i2cTx"
        status = self._OK
        _addr = 0
        if self.addr_endian == 'big':
            for i in range(self.addr_width):
                _addr = _addr * 256 + tx[i]
        else:    
            for i in range(self.addr_width):
                _addr = _addr *256 + tx[self.addr_width-1-i]
        self._reg_addr = _addr
        assert self._reg_addr < self.memory_size, "I2C allows only up to register addr ={} for write".format(self.memory_size-1)
        for i in range(self.addr_width,len(tx)):
            self._buffer[self._reg_addr] = tx[i]                      # write to buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr >= self.memory_size:
                self._reg_addr = self.memory_size-1                    # FIFO must be last
        self._log(fn_name)
        return status 

    def i2cRx(self,devaddr:int,rx_size:int) -> bytearray:
        """Function to receive bytes via I2C. """
        fn_name = "i2cRx"
        status = self._OK
        _rx = []
        assert self._reg_addr < self.memory_size, "I2C allows only up to register addr {} for read".format(self.memory_size-1)
        for i in range(rx_size):
            _rx = _rx + [self._buffer[self._reg_addr]]                       # read from buffer
            self._reg_addr += 1                                             # increment address buffer
            if self._reg_addr >= self.memory_size:
                self._reg_addr = self.memory_size-1                    # FIFO must be last
        self._log(fn_name)
        return bytearray( _rx )

    def i2cTxRx(self,devaddr:int,tx:list,rx_size:int) -> bytearray:
        """Function to transmit and receive bytes via I2C. """
        fn_name = "i2cTxRx"
        status = self._OK
        self._log(fn_name)
        self.i2cTx(devaddr,tx)
        return self.i2cRx(devaddr,rx_size)
    
# this is a test class - usefull for simple test of programs
if __name__ == "__main__":
    com = IcComMirrorFlex(memory_size=4*1024, addr_width=2,addr_endian='big')
    com.i2cOpen()
    com.i2cTx(0x11,[0x1, 0x12,  0x34,0x56,0x78,0x9a])
    com.i2cTx(0x11,[0x1, 0x12])
    assert [0x34,0x56,0x78,0x9a] == list( com.i2cRx(0x11,4) )
    fifo_addr = [(com.memory_size-1)//256, (com.memory_size-1)%256]
    com.i2cTx(0x11,fifo_addr+[1,2,3,4,5,6,7,8])
    assert com._reg_addr == com.memory_size-1, "Addr pointer stays at at {}".format(com.memory_size-1)
    assert com._buffer[com.memory_size-1] == 8, "last written value should be read back"
    assert [8,8,8,8] == list(com.i2cRx(0x11,4)), "Fifo read always same value from last address"
    com.i2cClose()
    

