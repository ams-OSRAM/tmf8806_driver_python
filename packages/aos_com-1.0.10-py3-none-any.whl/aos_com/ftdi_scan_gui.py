# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
"""

import aos_com.ftdi_mpsse as ftdi
import tkinter as tk
from tkinter import ttk 
from tkinter.scrolledtext import ScrolledText


def ftdi_scan():
    com = ftdi.FtdiMpsse(log=False)
    if ( com ):
        num_devices = com.getNumChannels()
        print( "Number devices found=", num_devices)
        disp = []
        if ( num_devices ):
            for i in range( num_devices ):
                dev_info = com.getChannelInfo( i )
                disp.append("---------------------------------------------------------------------")
                disp.append("Device number =" + str(i) )
                for field_name, field_type in dev_info._fields_:
                    print ( field_name, getattr(dev_info, field_name) )
                    disp.append( field_name + "=" + str( getattr( dev_info, field_name) ) )
                print( "NAME=" , getattr(dev_info, "SerialNumber"))
        else: 
            disp.append("No devices found")
        display_text.set(disp)
                    
if __name__ == "__main__":
    # create a list box
    root = tk.Tk()
    display_text = tk.StringVar()
    root.minsize(400,400)
    root.resizable(False, False)
    root.title('FTDI devices')
    #root.columnconfigure(0, weight=1)
    #root.columnconfigure(1, weight=1)
    #root.rowconfigure(0, weight=1)

    bt_scan = ttk.Button(root, text="Scan for devices", command=ftdi_scan )
    bt_scan.grid(row=0,column=0)
    bt_exit = ttk.Button(root, text="Exit", command=root.destroy )
    bt_exit.grid(row=1,column=0)
    lb_text = tk.Listbox(root, listvariable=display_text,height=20, width=80)
    lb_text['state']='disabled'
    lb_text.grid(row=2)
    ftdi_scan()
    root.mainloop()
