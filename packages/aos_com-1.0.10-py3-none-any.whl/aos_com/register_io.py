# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
This class allows to read and write registers or register+block
"""

import ctypes
from aos_com.ic_com import IcCom


class RegisterIo:    
    """Class that handles register read, register write, and register print.
       Uses IcCom for communication."""
       
    LOG_NONE = 0
    LOG_INFO = 1        # only print register info, no fifo, no block read
    LOG_VERBOSE = 10

    def __init__(self,ic_com:IcCom,dev_addr:int,log_level:int=LOG_INFO,i2c_print:bool=False,addr_width_in_bytes:int=1):
        """Constructor, stores the I2C slave address as device address
        Args:
            ic_com(IcCom): a communication class to talk i2c
            dev_addr(int): the 7-bit (unshifted) i2c slave address
            log_level(int, optional): how chatty this class shall be. Default is INFO level.
            ic_print (bool, optional): print all i2c communication in a format that is suitable to be used for digital simulations. Default is False.
            addr_width_in_bytes(int, optional): How many bytes shall be used for the register address. Defaults to 1. Set this e.g. to 2 if you have
            16-bit register addresses in your device. The endianess in this case is determined by the register itself automatically. I.e. the register
            must be derived from ctypes.BigEndianStructure or ctypes.LittleEndianStructure.
            """
        self.dev_addr = dev_addr
        self.com = ic_com
        self.log = log_level
        self.i2c_print = i2c_print
        self.addr_width = addr_width_in_bytes
    
    def addr2bytes(self,addr:int,endian) -> bytearray:
        """Function to convert the register address to a bytesteam in the defined byteorder
        with the definde address-width
        Args:
            addr(int): The register address
            endian: 'little' or 'big'
        Returns:
            bytearray : the address in bytes 
        """
        _val = int(addr).to_bytes(length=self.addr_width,byteorder=endian,signed=False)
        return bytearray( _val )

    def data2bytes(self,data,data_width,endian) -> bytearray:
        """Function to convert the data (list,value) to a bytesteam in the defined byteorder
        with the definde data-width
        Args:
            data(int|list): The data to be converted
            data_width: the number of byts needed
            endian: 'little' or 'big'
        Returns:
            bytearray : the data in bytes 
        """
        if type(data) == list:
            data = data                                                                 # data is a list
        else:                                                                           # single byte/integer
            data = [data]
        _data = b''
        for d in data:
            _data = _data + int(d).to_bytes(length=data_width,byteorder=endian,signed=False)
        return bytearray(_data)

    def _i2cTx(self,reg): 
        """Function calculates the transmit size based on the register size  and writes to i2c
        Args:
            reg: the register to be transmitted
        Returns:
            reg the written register
         """
        _endian = self.getEndian(reg)
        _addr = self.addr2bytes(reg.addr,_endian)
        _data = _addr + self._getBytes(reg)                                             # prepend the register address to bytearray of register value
        self.com.i2cTx(self.dev_addr, _data )                                           # transmit
        if self.i2c_print:
            print( "i2c_write({}, {}) ".format(reg.__class__.__name__, "".join("0x{:02x}, ".format( d ) for d in _data) ) )
        return reg

    def _i2cRx(self,reg):
        """Function calculates the receive size based on the register size  and reads from i2c
        Args:
            reg: the register to be read
        Returns:
            reg the read register
         """
        _rx_size = ctypes.sizeof(reg)
        _endian = self.getEndian(reg)
        _addr = self.addr2bytes(reg.addr,_endian)
        _data = self.com.i2cTxRx(self.dev_addr,_addr,_rx_size)
        self._setBytes(reg,_data)                                                           # set value to register
        if self.i2c_print:
            print( "i2c_read({}, {})    // data= {} ".format(reg.__class__.__name__, _rx_size, "".join("0x{:02x}, ".format( d ) for d in _data) ) )
        return reg                                                                      # return the register

    def _i2cBlockRead(self, reg, rx_size, prefix:str="") -> bytearray:
        """Read a variable sized number of bytes from the register. 
        Args:
            reg: a register whose values shall be read 
            rx_size: number of bytes to read
            prefix(str): what to print as function prefix
        Returns:
            bytearray read from the register.
        """
        _endian = self.getEndian(reg)
        _addr = self.addr2bytes(reg.addr,_endian)
        _data = self.com.i2cTxRx(self.dev_addr,_addr,rx_size)
        if self.log: 
            msg = "{}.{}, addr=0x{:02x}, rx_size={}".format( prefix, reg.__class__.__name__, reg.addr, rx_size )
            if self.log >= RegisterIo.LOG_VERBOSE:
                msg = msg + ", data:" + "".join(" 0x{:02x}".format( d ) for d in _data)
            print( msg )
        if self.i2c_print:
            print( "i2c_blockread({}, {})     // data= {} ".format(reg.__class__.__name__, rx_size, "".join("0x{:02x}, ".format( d ) for d in _data) ) )
        return _data

    def _i2cBlockWrite(self, reg, tx_data, prefix:str="") -> bytearray:
        """Write a variable sized number of bytes starting with the register specified.
        Args:
            reg: the register to start writing too
            tx_data: the byte, the list of bytes or bytarray to be written
            prefix(str): what to print as function prefix
        Returns:
            bytearray of written values
        """
        _endian = self.getEndian(reg)
        _addr = self.addr2bytes(getattr(reg,"addr"),_endian)
        if type(tx_data) == bytes or type(tx_data) == bytearray:
            _data = tx_data                                                                    # data is a bytearray
        elif type(tx_data) == list:            
            _data = bytearray(tx_data)
        elif type(tx_data) == int:
            _data = bytearray([tx_data])
        _tx_data = _addr + _data                                               # prepend the register address
        self.com.i2cTx(self.dev_addr, _tx_data )  
        if self.log: 
            _tx_size = len(_data)
            msg = "{}.{}, addr=0x{:02x}, tx_size={}".format( prefix, reg.__class__.__name__, _addr, _tx_size )
            if self.log >= RegisterIo.LOG_VERBOSE:
                msg = msg + "".join("{:02x}".format( d ) for d in _data)
            print( msg )
        if self.i2c_print:
            print( "i2c_blockwrite({}, {})".format(reg.__class__.__name__, "".join("0x{:02x}, ".format( d ) for d in _data) ) )
        return _data                                                            

    def _blockRead(self,reg,rx_size) -> bytearray:
        """Read a variable sized number of bytes from the register. Only the first register mirror is updated.
        But only the register itself.
        You probably want blockReadReg(...) and blockWriteReg(...) which updates the mirror for all read/written registers.
        Args:
            reg: a register whose values shall be read 
            rx_size: number of bytes to read
        Returns:
            bytearray read starting with the given register.
        """
        _data = self._i2cBlockRead(reg,rx_size,"blockRead")
        self._setBytes(reg=reg,data=_data)                                                       # set value to register only (not more than just this register)
        return _data

    def _blockWrite(self,reg,tx_data) -> bytearray:
        """Write a variable sized number of bytes starting with the register specified. 
        Only the start register value will be stored in the mirror register. 
        You probably want blockReadReg(...) and blockWriteReg(...) which updates the mirror for all read/written registers.
        Args:
            reg: the register to start writing too
            tx: the byte, the list of bytes or bytarray to be written
        Returns:
            bytearray written
        """
        _data = self._i2cBlockWrite(reg,tx_data,"blockWrite")
        self._setBytes(reg=reg,data=_data)                                                           # set value to register only
        return _data

    def _updateRegs(self,device,reg,data):
        """Function that will update multiple registers after a block read or block write
        Args:
            device: the device register class, is needed to walk through the registers for updating them
            reg: the register to start updating the mirrored values
            data: the byte, the list of bytes or bytarray to be used for updates
        """
        _endian = self.getEndian(reg)
        if type(data) == bytes or type(data) == bytearray:
            _data = data                                                                    # data is a bytearray
        elif type(data) == list:            
            _data = bytearray(data)
        elif type(data) == int:
            _data = bytearray([data])
        _start_addr = reg.addr
        _offset = 0
        for _v in vars(device):                                                             # linear search for correct registers to update
            _reg = getattr(device,_v)
            if _offset < len(_data):
                if _reg.addr == _start_addr + _offset:                                      # make sure we skip "register-holes"
                    self._setBytes(_reg,_data[_offset:])                                    # set it as a list
                    _size = ctypes.sizeof(_reg)
                    _offset += _size
            else:
                return                                                                      # all done, early exit

    @staticmethod
    def _setBytes(reg,data:bytearray,use_last_bytes:bool=False):
        """Function to set the register to the given bytearray value by memmove. Use this after reading a register with i2c which constists of more than 1 byte.
        This does not change the byte order at all - I.e. the data is written to the register in the same byte-order as it was provided!!! 
        Args:
            val_b(bytes):a byte array to be used for setting, must contain at least as many bytes as needed for the register
            reverse(bool): if True use the last <n> bytes for value
        Returns:
            reg the set register
        """
        _size = ctypes.sizeof(reg)
        assert _size <= len(data), "The data is too small for {}".format(reg.__class__.__name__)
        if use_last_bytes:
            _value = data[-_size:]                                 # use the last _size elements
        else:
            _value = data[0:_size]                                 # use the first _size elements
        _dst = ctypes.byref(reg)
        ctypes.memmove(_dst, bytes(_value), _size)
        return reg

    def _set(self,reg,value):
        """Function to set the register to the given single integer value 
        Args:
            value(int):an 8, 16 or 32 bit value to which the register (depending on size should be set)
        Returns:
            reg the set register
        """
        _data_width = ctypes.sizeof(reg)
        _endian = self.getEndian(reg)
        _data = self.data2bytes(value,_data_width,_endian)
        return RegisterIo._setBytes(reg,_data)

    @staticmethod
    def _getBytes(reg):
        """Function to get the register value as bytearray
        Returns:
            bytearray representing the register value, endianess is defined by object itself 
            (ctypes.LittleEndianStructure or ctypes.BigEndianStructure)
        """
        return bytearray(reg)                                                   # read the complete value of the register as a bytearray

    @staticmethod
    def getEndian(reg):
        if isinstance(reg,ctypes.LittleEndianStructure) and not isinstance(reg,ctypes.BigEndianStructure):
            _str = 'little'
        elif isinstance(reg,ctypes.BigEndianStructure) and not isinstance(reg,ctypes.LittleEndianStructure):
            _str = 'big'
        else:                                           # older python versions did not resolve isinstance for tuples of types, so try harder to find out
            _bases = str( reg.__class__.__bases__ )
            if _bases.find( "LittleEndianStructure") >= 0:
                _str = 'little'
            elif _bases.find( "BigEndianStructure") >= 0:
                _str = 'big'
            else:
                if ctypes.sizeof(reg) == 1:             # for single byte registers, we do not care about byte-endianess
                    _str = 'little'                     # default to little-endian
                else:                                   # multi-byte registers must have there endianess defined
                    raise Exception( "Object {} is not a register that is based on ctypes.LittleEndianStructure or ctypes.BigEndianStructure".format(reg))
        return _str
    
    @staticmethod
    def get(reg):
        """Function to get the register value as a single integer
        Returns:
            value(int):an 8, 16 or 32 bit value to which the register (depending on size should be set), 
            endianess is defined by the object itself (ctypes.LittleEndianStructure or ctypes.BigEndianStructure)
        """
        _size = ctypes.sizeof(reg)
        assert _size <= 4, "The register {} is not a <= 4-byte value".format(reg.__class__.__name__)
        _endian = RegisterIo.getEndian(reg)
        _val_b = RegisterIo._getBytes(reg)
        _val = int.from_bytes(bytes=_val_b,byteorder=_endian,signed=False)
        return _val                                                         # a single integer

    @staticmethod
    def regDump(reg):
        """Returns a string containing the register content
        Args:
            reg: a register 
        """
        _addr = getattr( reg, "addr" )       
        _bits=[]
        for _idx, _field in enumerate( reg._fields_):                                       # loop over all membbers
            _name = _field[0]                                                               # get bitfield name
            _value = getattr(reg,_name)                                                     # get bitfield value
            _bits.append("{}={}".format(_name,hex(_value)))                                 # collect all bit-fields in one list
        _val_reg_b = RegisterIo._getBytes(reg)                                              # read register as a bytearray
        _val_reg_i = RegisterIo.get(reg)                                                    # read register as a single integer
        return "{}, addr=0x{:02x}, fields={}, val=0x{:x}".format( reg.__class__.__name__, _addr, _bits, _val_reg_i )

    @staticmethod
    def regPrint(reg, prefix:str=""):
        """Print the register content
        Args:
            reg: a register 
            prefix(str): for using this function also to print read or write with a prefix, leave empty for direct call 
        """
        if not prefix:
            prefix = "regPrint."
        print( "{}{}".format( prefix, RegisterIo.regDump(reg) ))

    def regReadModifyWrite(self,reg, **kwargs):
        """Read register from device, modify specified bitfields and write register to device
        Args:
            reg: a register whose values shall be changed 
            kwargs: a dictionary with the bitfield names (as key), and the value for the bitfield. Use
                special bitfield name val to set the complete register value
        Returns:
            reg the changed register.
        """
        self.regRead( reg )                       # read the register from device
        return self.regWrite (reg, **kwargs )        # modify and write the register to the device

    def regWrite(self, reg, **kwargs):
        """Write bitfields to register
        Args:
            reg: a register whose values shall be changed 
            kwargs: a dictionary with the bitfield names (as key), and the value for the bitfield. Use
                special bitfield name val to set the complete register value
        Returns:
            reg the changed register.
        """
        _bits=[]
        for _name, _value in kwargs.items():
            if hasattr(reg,_name):
                setattr(reg,_name,_value)
                _bits.append("{}={}".format(_name,hex(_value)))
            elif _name == "val":     # special value parameter, set complete register 
                self._set(reg,_value)
                _bits.append("{}={}".format(_name,hex(_value)))
            else:
                print( "{} has no field {}".format(reg.__class__.__name__, _name) )
                raise Exception("{} has no field {}".format(reg.__class__.__name__, _name))
        self._i2cTx(reg)
        if self.log:
            _addr = getattr( reg, "addr" )       
            _val_reg_b = RegisterIo._getBytes(reg)                                  # read register as a bytearray
            _val_reg_i = RegisterIo.get(reg)                                        # read register as a single integer
            print( "{}{}, addr=0x{:02x}, fields={}, val=0x{:x}".format( "regWrite.", reg.__class__.__name__, _addr, _bits, _val_reg_i ))
        return reg
    
    def regRead(self, reg):
        """Read register
        Args:
            reg: a register whose values shall be read 
        Returns:
            reg the read register.
        """
        self._i2cRx(reg)
        if self.log: 
            self.regPrint(reg, prefix = "regRead.")
        return reg
        
    def regReadExpect(self,reg, **kwargs):
        """Read the register and compare the all the given bit-fields against the specified values. This 
        is a logical AND comparison. I.e. all the values given must match to get a True back.
        Args:
            reg: a register whose values shall be changed 
            kwargs: a dictionary with the bitfield names (as key), and the value for the bitfield. Use
                special bitfield name val to compare against the complete register value
        Returns:
            True if all the given values are set in the register
            False else
        """
        _bits=[]
        _i2c_print = self.i2c_print
        self.i2c_print = False                      # disable temporarily i2c printing
        self.regRead(reg)     
        self.i2c_print = _i2c_print          
        _is_same = True
        for _name, _value in kwargs.items():
            if hasattr(reg,_name):
                _read_value = getattr(reg,_name)
                _bits.append("{}={}, expected={}".format(_name,hex(_read_value),hex(_value)))
                if _read_value != _value:                                                     # get bitfield value different value
                    _is_same = False
            elif _name == "val":     # special value parameter, set complete register
                _read_value = self.get(reg) 
                _bits.append("{}={}, exptected={}".format(_name,hex(_read_value),hex(_value)))
                if _read_value != _value:
                    _is_same = False
            else: 
                print( "{} has no field {}".format(reg.__class__.__name__, _name) )
                raise Exception("{} has no field {}".format(reg.__class__.__name__, _name))
        if self.log:
            _addr = getattr( reg, "addr" )       
            _read_value = self.get(reg) 
            print( "{}{}, addr=0x{:02x}, fields={}, val=0x{:x}".format( "regReadExpect.", reg.__class__.__name__, _addr, _bits, _read_value ))
        if self.i2c_print:
            print( "i2c_readexpect({}, {} ) // data = {}  ".format(reg.__class__.__name__, ctypes.sizeof(reg), _bits ) )
        return _is_same

    def fifoRead(self, fifo, rx_size) -> bytearray:
        """Read a variable sized number of bytes from the fifo.
        Args:
            fifo: a fifo register whose values shall be read 
            rx_size: number of bytes to read
        Returns:
            bytearray read from the fifo.
        """
        _data = self._i2cBlockRead(reg=fifo, rx_size=rx_size, prefix="fifoRead")
        self._setBytes(reg=fifo,data=_data,use_last_bytes=True)                                                       # set value to register - fifo is typically last value
        return _data

    def fifoWrite(self,fifo,tx_data) -> bytearray:
        """Write a variable sized number of bytes from the fifo.
        Args:
            fifo: a fifo register whose values shall be written
            tx_data: the byte, the list of bytes or bytarray to be written
        Returns:
            bytearray written to the fifo.
        """
        _data = self._i2cBlockWrite(reg=fifo, tx_data=tx_data, prefix="fifoWrite")
        self._setBytes(reg=fifo,data=_data,use_last_bytes=True)                                                       # set value to register - fifo is typically last value
        return _data

    def blockReadReg(self,device,reg,rx_size) -> bytearray:
        """Read a variable sized number of bytes from the register. Useful for read FIFO. The register mirror is updated too.
        But only the register itself.
        When you use this function for regular register you need to be aware that the block-read will not update the mirror
        registers, so you should only use this function together with regRead(...) and regReadWrite().
        Args:
            device: the class the register belongs to, also the class whose registers will get updated
            reg: a register whose values shall be read 
            rx_size: number of bytes to read
        Returns:
            bytearray read from the register.
        """
        _data = self._i2cBlockRead(reg,rx_size,"blockRead")
        self._updateRegs(device,reg,_data)
        return _data

    def blockWriteReg(self,device,reg,tx_data) -> bytearray:
        """Write a variable sized number of bytes starting with the register specified. Useful for write FIFO.
        Only the start register value will be stored in the mirror register. 
        When you use this function for regular register you need to be aware that the block-read will not update the mirror
        registers, so you should only use this function together with regRead(...) and regReadWrite().
        Args:
            device: the class the register belongs to, also the class whose registers will get updated
            reg: the register to start writing too
            tx: the byte, the list of bytes or bytarray to be written
        Returns:
            bytearray written to the registers.
        """
        _data = self._i2cBlockWrite(reg,tx_data,"blockWrite")
        self._updateRegs(device,reg,_data)
        return _data

    # below is same for all devices
    @staticmethod
    def regMapPrint(device):
        """Print all registers with address and field info"""
        print("{} Register Map:".format(device.__class__.__name__))
        for _v in vars(device):
            _reg = getattr(device,_v)
            RegisterIo.regPrint(_reg)

    def regMapRead(self,device):
        """Read all registers from device """
        print( "{} read Register Map from device:".format(device.__class__.__name__))
        for _v in vars(device):
            _reg = getattr(device,_v)
            self.regRead(_reg)

    @staticmethod
    def regByAddr(device,addr):
        """Find the register with the given addr"""
        for _v in vars(device):
            _reg = getattr(device,_v)
            if getattr(_reg,"addr") == addr:
                return _reg
        raise Exception( "No register with address {} exists".format(hex(addr)))

def ctypes2Dict(frame):
    """To convert a simple ctypes frame into a dictionary call this function. this is a recursive function.
    Args:
        frame: a ctpye structure/list
    """
    # if the type is not a primitive and it evaluates to False ...
    if (type(frame) not in [int, float, bool]) and not bool(frame):
        # it's a null pointer
        return 0
    elif (type(frame) in [int, float, bool]):
        return frame
    elif hasattr(frame, "_length_") and hasattr(frame, "_type_"):
        # Probably an array
        return list(map(ctypes2Dict, frame))
    elif hasattr(frame, "_fields_"):
        result = {}
        for temp in frame._fields_:
            field = temp[0]
            v = getattr(frame, field)
            result[field] = ctypes2Dict(v)
        return result
    return None

def dict2Ctypes(struct_type, values):
    """Convert a dictionary back to a ctypes Structure/Array.

    Args:
        struct_type (class): The data type to be filled. Must be of base class ctypes.Structure|ctypes.Array.
        values (dict|array): The dictionary or array which was previously generated by ctypes2Dict().
    Returns: 
        struct_type: A ctypes instance with the data from the dictionary.
        
    Example::

        class DummyStructure(ctypes.LittleEndianStructure):
            _pack_ = 1
            _fields_ = [ 
                ("bitfield1", ctypes.c_uint8, 1),
                ("bitfield2", ctypes.c_uint8, 7),
                ("array", ctypes.c_uint8*6),
                ]
        data = DummyStructure()
        data.bitfield1 = 1
        data.bitfield2 = 23
        data.array = (ctypes.c_uint8*6)(*range(6))
        print([hex(x) for x in bytes(data)])
        data_dict = ctypes2Dict(data)
        print(data_dict)
        data_recovered = dict2Ctypes(DummyStructure, data_dict)
        print([hex(x) for x in bytes(data_recovered)])
    """
    def _dict2Ctypes(dst, value):
        """ A helper function to pass the ctypes instance by reference. Is called recursively."""
        if type(value) is list:
            assert hasattr(dst, "_length_")
            for i, v in enumerate(value):
                if type(v) in [int, float, bool]:
                    dst[i] = v
                else:
                    _dict2Ctypes(dst[i], v)
        elif type(value) is dict:
            for field_name in value:
                v = value[field_name]
                if type(v) in [int, float, bool]:
                    assert hasattr(dst, field_name)
                    setattr(dst, field_name, v)
                else:
                    _dict2Ctypes(getattr(dst, field_name), v)
        else:
            assert False, "Types other than lists or structs are not allowed."
        pass
    res = struct_type()
    _dict2Ctypes(res, values)
    return res
